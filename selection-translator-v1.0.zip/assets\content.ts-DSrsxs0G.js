(function(){var e=null,t=null,n=null,r=null,i=`
<style>
  :host { all: initial; }
  .trans-icon {
    width: 32px;
    height: 32px;
    background: #4f46e5;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    box-shadow: 0 2px 12px rgba(79, 70, 229, 0.35);
    animation: iconIn 0.15s ease-out;
    transition: transform 0.15s;
  }
  .trans-icon:hover {
    transform: scale(1.1);
    background: #4338ca;
  }
  @keyframes iconIn {
    from { opacity: 0; transform: scale(0.7); }
    to { opacity: 1; transform: scale(1); }
  }
  .icon-svg {
    width: 16px;
    height: 16px;
    fill: #ffffff;
  }
</style>
<div class="trans-icon" id="transIcon">
  <svg class="icon-svg" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path d="M12.87 15.07l-2.54-2.51.03-.03A17.52 17.52 0 0014.07 6H17V4h-7V2H8v2H1v2h11.17C11.5 7.92 10.44 9.75 9 11.35 8.07 10.32 7.3 9.19 6.69 8h-2c.73 1.63 1.73 3.17 2.98 4.56l-5.09 5.02L4 19l5-5 3.11 3.11.76-2.04zM18.5 10h-2L12 22h2l1.12-3h4.75L21 22h2l-4.5-12zm-2.62 7l1.62-4.33L19.12 17h-3.24z"/>
  </svg>
</div>
`,a=`
<style>
  :host { all: initial; }
  .popup {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.12), 0 2px 8px rgba(0, 0, 0, 0.06);
    padding: 16px;
    width: 360px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 14px;
    line-height: 1.5;
    color: #1a1a2e;
    animation: fadeIn 0.15s ease-out;
    position: relative;
  }
  .popup::before {
    content: '';
    position: absolute;
    top: -8px;
    left: 50%;
    transform: translateX(-50%);
    width: 0;
    height: 0;
    border-left: 8px solid transparent;
    border-right: 8px solid transparent;
    border-bottom: 8px solid #ffffff;
    filter: drop-shadow(0 -1px 1px rgba(0, 0, 0, 0.04));
  }
  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(4px); }
    to { opacity: 1; transform: translateY(0); }
  }
  .section-label {
    font-size: 11px;
    color: #94a3b8;
    margin-bottom: 4px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }
  .source-text {
    font-size: 13px;
    color: #475569;
    margin-bottom: 12px;
    line-height: 1.5;
    word-break: break-word;
  }
  .source-text.truncated::after {
    content: ' [原文已截断]';
    color: #f59e0b;
    font-size: 11px;
  }
  .loading {
    display: flex;
    align-items: center;
    gap: 8px;
    color: #94a3b8;
    font-size: 13px;
  }
  .spinner {
    width: 14px;
    height: 14px;
    border: 2px solid #e2e8f0;
    border-top-color: #4f46e5;
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
  }
  @keyframes spin {
    to { transform: rotate(360deg); }
  }
  .result-text {
    font-size: 15px;
    color: #1e1b4b;
    font-weight: 500;
    line-height: 1.6;
    margin-bottom: 12px;
    word-break: break-word;
  }
  .error {
    color: #dc3545;
    font-size: 13px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
  }
  .actions {
    display: flex;
    justify-content: flex-end;
    gap: 8px;
  }
  .btn {
    padding: 4px 12px;
    font-size: 12px;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    background: #ffffff;
    color: #475569;
    cursor: pointer;
    transition: all 0.15s;
    font-family: inherit;
    line-height: 1.5;
  }
  .btn:hover {
    background: #f8fafc;
    border-color: #cbd5e1;
  }
  .btn-copied {
    background: #f0fdf4;
    color: #16a34a;
    border-color: #86efac;
  }
</style>
<div class="popup" id="popup">
  <div class="section-label">原文</div>
  <div class="source-text" id="source"></div>
  <div id="loading">
    <div class="loading">
      <div class="spinner"></div>
      <span>翻译中...</span>
    </div>
  </div>
  <div id="result" style="display:none">
    <div class="section-label">译文</div>
    <div class="result-text" id="resultText"></div>
    <div class="actions">
      <button class="btn" id="copyBtn">复制</button>
    </div>
  </div>
  <div id="error" style="display:none">
    <div class="section-label">译文</div>
    <div class="error">
      <span id="errorText"></span>
      <button class="btn" id="retryBtn">重试</button>
    </div>
  </div>
</div>
`,o=5e3;document.addEventListener(`mouseup`,e=>{setTimeout(()=>s(e),0)});function s(e){let t=window.getSelection();if(!t||t.isCollapsed)return;let i=t.toString().trim();i&&(c(e.target)||(n=i.length>o?i.slice(0,o):i,r=t.getRangeAt(0).getBoundingClientRect(),g(),l()))}function c(n){return!!(e&&e.contains(n))||!!(t&&t.contains(n))}function l(){if(!r)return;h();let t=r;e=document.createElement(`div`),e.id=`__trans-icon-host`;let a=e.attachShadow({mode:`open`});a.innerHTML=i,document.body.appendChild(e),e.style.cssText=`
    position: fixed;
    z-index: 2147483646;
    left: ${t.right+4}px;
    top: ${t.top-28}px;
  `,a.getElementById(`transIcon`).addEventListener(`click`,e=>{e.stopPropagation(),h(),u(n)})}function u(e){if(!r)return;let n=r,i=n.left+n.width/2,o=n.bottom+8;g(),t=document.createElement(`div`),t.id=`__trans-popup-host`;let s=t.attachShadow({mode:`open`});s.innerHTML=a,document.body.appendChild(t),p(s),t.style.cssText=`
    position: fixed;
    z-index: 2147483647;
    left: ${i}px;
    top: ${o}px;
    transform: translateX(-50%);
  `,d(s,`source`).textContent=e,f(s,`loading`),m(e,s)}function d(e,t){return e.getElementById(t)}function f(e,t,n,r){let i=d(e,`loading`),a=d(e,`result`),o=d(e,`error`);i.style.display=t===`loading`?`block`:`none`,a.style.display=t===`result`?`block`:`none`,o.style.display=t===`error`?`block`:`none`,t===`result`&&n&&(d(e,`resultText`).textContent=n),t===`error`&&r&&(d(e,`errorText`).textContent=r)}function p(e){d(e,`copyBtn`).addEventListener(`click`,()=>{let t=d(e,`resultText`).textContent;t&&navigator.clipboard.writeText(t).then(()=>{let t=d(e,`copyBtn`);t.textContent=`已复制`,t.classList.add(`btn-copied`),setTimeout(()=>{t.textContent=`复制`,t.classList.remove(`btn-copied`)},2e3)})}),d(e,`retryBtn`).addEventListener(`click`,()=>{n&&(f(e,`loading`),m(n,e))})}function m(e,n){chrome.runtime.sendMessage({type:`TRANSLATE`,text:e},e=>{t&&(chrome.runtime.lastError?f(n,`error`,void 0,`翻译请求失败: `+chrome.runtime.lastError.message):e?.success?f(n,`result`,e.translated):f(n,`error`,void 0,e?.error||`翻译失败`))})}function h(){e&&=(e.remove(),null)}function g(){t&&=(t.remove(),null)}document.addEventListener(`click`,i=>{let a=i.target;e&&!e.contains(a)&&(h(),r=null),t&&!t.contains(a)&&(g(),n=null,r=null)}),document.addEventListener(`keydown`,e=>{e.key===`Escape`&&(h(),g(),n=null,r=null)});})()
